package com.android.weighttrackingapp;

import static com.android.weighttrackingapp.R.id.addWeightInputBox;
import static com.android.weighttrackingapp.R.id.emptyTextCheck;
import static com.android.weighttrackingapp.R.id.emptyWeightInputContainer;
import static com.android.weighttrackingapp.R.id.weightitem;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.Layout;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.GridView;
import android.widget.SimpleCursorAdapter;
import android.widget.Toast;

import java.util.List;

public class AddWeightItemActivity extends AppCompatActivity {
    //variables for the activity
    private Activity addingWeightAct;
    private WeightEntryItemsDatabase weightDB;
    private List<WeightEntryItem> weItemList;
    private Layout gridLay;
    private String date, data;
    private int currIndex;
    private WeightEntryItem weItem;
    private GridView gridView;
    private EditText weightInput;
    private View addItemPopup, emptyItemPopup, gridListView, loginView;
    private PopupWindow addItemPopView, emptyItemPopView;
    private Button deleteButton, addWeightButton, editButton, logoutButton, submitEntryButton, closeButton;
    private LayoutInflater inflate;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.fragment_grid_item_list);

        weightDB = WeightEntryItemsDatabase.getInstance(getApplicationContext());
        addingWeightAct = this;
        loginView = findViewById(R.id.loginScreen);
        //setting up buttons
        deleteButton = findViewById(R.id.deleteRowButton);
        addWeightButton = findViewById(R.id.addWeightItemButton);
        editButton = findViewById(R.id.editItemButton);
        logoutButton = findViewById(R.id.logoutButton);
        submitEntryButton = findViewById(R.id.submitWeightButton);
        closeButton = findViewById(R.id.closeButton);

        //assign input values to variables
        date = weItem.getDate().toString();
        data = weightInput.getText().toString();

        //assign layouts
        gridView = findViewById(R.id.weightitem);
        addItemPopup = findViewById(R.id.addWeightLayout);
        emptyItemPopup = findViewById(R.id.emptyWeightInputContainer);
        gridListView = findViewById(R.id.weightItemsGrid);

        //inflate layout
        getWeightList();
        for(int i = 0; i < weItemList.size(); i++){
           data = weItemList.get(i).toString();
           gridView = (GridView) inflate.inflate(R.layout.fragment_grid_item_list, addingWeightAct.findViewById(weightitem));
        }

        //get intent
        Intent intent = getIntent();

        int pos = intent.getExtras().getInt("id");

        /////button listeners///////
        //add weight button listener
        addWeightButton.setOnClickListener(addItemPopup ->{
            setContentView(addItemPopup);
            weightInput = findViewById(R.id.addWeightInputBox);
            data = weightInput.getText().toString();
            //submit weight item button listener
            submitEntryButton.setOnClickListener((View v) ->{
                //make sure input isn't empty
                if(TextUtils.isEmpty(data)) {
                    inflate = addingWeightAct.getLayoutInflater();
                    emptyItemPopup = inflate.inflate(R.layout.empty_weight_popup, addingWeightAct.findViewById(emptyWeightInputContainer));

                    //set up popup window
                    emptyItemPopView = new PopupWindow(emptyItemPopup, 500, 500, true);
                    emptyItemPopView.showAtLocation(emptyItemPopup, Gravity.CENTER, 0, 0);

                    //button onClick listener to close the window
                    closeButton.setOnClickListener(popView -> {
                        emptyItemPopView.dismiss();
                    });
                }else{
                    data = weightInput.getText().toString();
                    addWeightEntry(data);
                    setContentView(R.layout.fragment_grid_item_list);
                }
                ClearData();

            }); //End of submitEntryButton listener
        }); //End of addWeightButton listener

        //delete button listen her
        deleteButton.setOnClickListener(view ->{
            weItem = new WeightEntryItem(data, date);
            weightDB.deleteAWeightEntry(weItem);
        }); //Ends delete button listener

        //edit button listener
        editButton.setOnClickListener(view -> {
            weItem = new WeightEntryItem(data, date);
            weightDB.updateDailyWeight(weItem);
        }); //End of editbutton listener

        //logout button listener
        logoutButton.setOnClickListener(view ->{
            setContentView(loginView);
        } ); //End of logout Button
    }

    public void addWeightEntry(String currWeight){
        //make sure the weight is > 0
        if(currWeight.length() > 0){
            weItem.setUserWeight(currWeight);
            weItem = new WeightEntryItem(currWeight, date);

            //add to db
            weightDB.addDailyWeightEntry(weItem);
        }
    }

    //method to clear the add weight item screen
    public void ClearData(){
        weightInput.getText().clear();
    }

    public List<WeightEntryItem> getWeightList(){
        weItemList = weightDB.getDailyWeightTTables();
        return weItemList;
    }

}