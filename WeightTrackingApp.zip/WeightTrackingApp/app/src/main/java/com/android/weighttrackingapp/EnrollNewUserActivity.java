package com.android.weighttrackingapp;

import android.os.Bundle;
import android.widget.Toast;

import androidx.fragment.app.FragmentActivity;

/*
 * Main Activity class that loads {@link MainFragment}.
 */
public class EnrollNewUserActivity extends FragmentActivity {
    private String newAccUser, newAccPass;
    private WeightEntryItemsDatabase db;
    private User newUser;
    private boolean userCheck;

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        setContentView(R.layout.fragment_grid_item_list);
    }

    public void addNewUser(String newU, String newP){
        newAccUser = newU;
        newAccPass = newP;
        newUser = new User(newAccUser, newAccPass);
        userCheck = db.checkUser(newAccUser, newAccPass);
        if(!userCheck){
            db.addNewUser(newUser);
        }else{
            Toast.makeText(getApplicationContext(), "Username already in use. Please try again.", Toast.LENGTH_LONG).show();
            setContentView();
        }


    }
}