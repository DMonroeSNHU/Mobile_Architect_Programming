package com.android.weighttrackingapp;

public class GoalWeight {
    private long userId;
    private double goalWeight;

    public GoalWeight() {}

    public GoalWeight(double Weight) {
        goalWeight = Weight;
    }

    //Getters
    public double getWeight() {
        return goalWeight;
    }
    public long getId() {
        return userId;
    }

    //Setters
    public void setWeight(double Weight) {
        goalWeight = Weight;
    }
    public void setId(long id) {
        userId = id;
    }
}
