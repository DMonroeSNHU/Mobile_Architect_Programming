package com.android.weighttrackingapp;

import android.os.Bundle;

import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.GridView;
import android.widget.TextView;

public class GridItemList extends Fragment {

    private static final String ARG_PARAM1 = "uWeight";
    private static final String ARG_PARAM2 = "date";

    private GridView itemContainer;
    private View view;
    private TextView userDataView;
    private String uWeight;
    private String date;

    public GridItemList() {
        // Required empty public constructor
    }

    /**
     * Use this factory method to create a new instance of
     * this fragment using the provided parameters.
     *
     * @param param1 Parameter 1.
     * @param param2 Parameter 2.
     * @return A new instance of fragment GridItemList.
     */
    // TODO: Rename and change types and number of parameters
    public static GridItemList newInstance(String weight, String date) {
        GridItemList fragment = new GridItemList();
        Bundle args = new Bundle();
        args.putString("weight", weight);
        args.putString("date", date);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
             uWeight = getArguments().getString("weight");
            date = getArguments().getString("date");
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        view = inflater.inflate(R.layout.)
        return inflater.inflate(R.layout.fragment_grid_item_list, container, false);
    }
}