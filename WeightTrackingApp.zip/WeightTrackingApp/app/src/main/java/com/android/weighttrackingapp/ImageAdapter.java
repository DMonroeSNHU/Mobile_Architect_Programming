package com.android.weighttrackingapp;
import android.content.Context;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;

public class ImageAdapter extends BaseAdapter {
    private Context mContext;

    //constructor
    public ImageAdapter(Context c){
        mContext = c;
    }

    //gets
    public int getCount(){
        return mThumbIds.length;
    }
    public Object getItem(int position){
        return null;
    }
    public long getItemId(int position){
        return 0;
    }

    //new ImageView for each item
    public View getView(int position, View newView, ViewGroup parentView){
        ImageView newImageView;

        //if statement to set the parameters for each GridView component
        if(newView == null){
            newImageView = new ImageView(mContext);
            newImageView.setLayoutParams(new ViewGroup.LayoutParams(70,70));
            newImageView.setScaleType(ImageView.ScaleType.CENTER_CROP);
            newImageView.setPadding(3, 3, 3, 3);
        }else{
            newImageView = (ImageView) newView;
        }
        newImageView.setImageResource((mThumbIds[position]));
        return newImageView;
    }

    public Integer[] mThumbIds = {

    };

}
