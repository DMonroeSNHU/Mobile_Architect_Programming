package com.android.weighttrackingapp;

import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.AdapterView;
import android.widget.PopupWindow;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    //variables for mainactivity
    private Activity login;
    private Button loginButton, createAccButton, closeButt;
    private EditText usernameInput, passwordInput, newUsernameInput, newPasswordInput;
    private String username, password, newAccUsername, newAccPassword;
    private WeightEntryItemsDatabase weightDB;
    private Intent intent;
    private PopupWindow messageToUser;
    private View popView;
    private EnrollNewUserActivity enroll;
    private User user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        weightDB = WeightEntryItemsDatabase.getInstance(getApplicationContext());
        //assign variables to appropriate view by id
        login = this;
        //login and create account buttons
        loginButton = findViewById(R.id.loginButton);
        createAccButton = findViewById(R.id.createAccButton);
        //EditText Views
        usernameInput = findViewById(R.id.usernameInputBox);
        passwordInput = findViewById(R.id.passwordInputBox);
        newUsernameInput = findViewById(R.id.createUsernameInputBox);
        newPasswordInput = findViewById(R.id.createPasswordInputBox);

        //close popup window button
        closeButt = findViewById(R.id.closeButton);

        //setting onClick Listeners for buttons
        loginButton.setOnClickListener(view ->{
            username = usernameInput.getText().toString();
            password = passwordInput.getText().toString();

            //if statement to make sure the inputs aren't empty
            if(TextUtils.isEmpty(username) || TextUtils.isEmpty(password)){
                LayoutInflater inflate = login.getLayoutInflater();
                 popView = inflate.inflate(R.layout.empty_input_popup, login.findViewById(R.id.emptyInputPopupViewContainer));

                //set up popup window
                messageToUser = new PopupWindow(popView, 500, 500, true);
                messageToUser.showAtLocation(popView, Gravity.CENTER, 0, 0);

                //button onClick listener to close the window
                closeButt.setOnClickListener(popView ->{
                    messageToUser.dismiss();
                    });
            }else{
                if(!weightDB.checkUser(username, password)){

                }
                setContentView(R.layout.fragment_grid_item_list);
                ClearLoginScreen();
            }
       });

        createAccButton.setOnClickListener(view ->{
            ///use an if statement to check if input is empty
            //if empty popup window if not create user method
            newAccUsername = newUsernameInput.getText().toString();
            newAccPassword = newPasswordInput.getText().toString();

            //if statement to make sure the inputs aren't empty
            if(TextUtils.isEmpty(newAccUsername) || TextUtils.isEmpty(newAccPassword)){
                LayoutInflater inflate = login.getLayoutInflater();
                popView = inflate.inflate(R.layout.empty_input_popup, login.findViewById(R.id.emptyInputPopupViewContainer));

                //set up popup window
                messageToUser = new PopupWindow(popView, 500, 500, true);
                messageToUser.showAtLocation(popView, Gravity.CENTER, 0, 0);

                //button onClick listener to close the window
                closeButt.setOnClickListener(popView ->{
                    messageToUser.dismiss();
                });
            }else{
                user = new User(newAccUsername, newAccPassword);
                weightDB.addNewUser(user);
                setContentView(R.layout.fragment_grid_item_list);
                ClearLoginScreen();
            }
        });

        GridView gridView = (GridView) findViewById(R.id.weightitem);
        gridView.setAdapter(new ImageAdapter(this));
        gridView.setOnItemClickListener(new OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                //send intent
                Intent intent = new Intent(getApplicationContext(), AddWeightItemActivity.class);
                intent.putExtra("id", position);
                startActivity(intent);
            }
        });

    }

    public void ClearLoginScreen(){
        usernameInput.getText().clear();
        passwordInput.getText().clear();
        newUsernameInput.getText().clear();
        newPasswordInput.getText().clear();
    }

    public void Login(){

    }
}