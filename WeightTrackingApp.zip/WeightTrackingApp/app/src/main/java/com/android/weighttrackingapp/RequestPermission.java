package com.android.weighttrackingapp;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentManager;

import android.app.Dialog;
import android.os.Bundle;

public class RequestPermission extends AppCompatActivity {

    private Dialog askUser;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_request_permission);
        askPermission();

    }

    public void askPermission(){
        AskPermissionDialogFragment askUser = new AskPermissionDialogFragment();
        askUser.show(getSupportFragmentManager(), "AskPermissionDialogFragment");
    }
}