package com.android.weighttrackingapp;

public class User {
    private String nameUser;
    private long idUser;
    private String passwordUser;

    public User() {}

    public User (String uName, String pWord) {
        //mId = id;
        nameUser = uName;
        passwordUser = pWord;
    }

    //Getters
    public String getUser() {
        return nameUser;
    }
    public String getPassword() {
        return passwordUser;
    }
    public long getId() {
        return idUser;
    }

    //Setters
    public void setUser(String uName) {
        nameUser = uName.toLowerCase();
    }
    public void setPassword(String pWord) {
        passwordUser = pWord;
    }
    public void setId(long id) {
        idUser = id;
    }


}
