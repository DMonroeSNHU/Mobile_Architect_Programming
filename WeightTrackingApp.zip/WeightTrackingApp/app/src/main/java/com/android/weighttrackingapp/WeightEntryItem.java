package com.android.weighttrackingapp;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.time.format.DateTimeFormatter;
public class WeightEntryItem {

    //private variables to create a Weight Item
    private long uId;
    private String userId;
    private String userWeight;

    //get current date
    private Date today;
    private SimpleDateFormat formatter = new SimpleDateFormat();
    private String weightEntryDate;

    //constructor function
    public WeightEntryItem(String UWeight, String currentDate){
        //set value
        userWeight = UWeight;
        weightEntryDate = currentDate;
    }

    public WeightEntryItem() {

    }

    //Getters
    public long getUId(){
        return uId;
    }
    public String getUserId(){
        return userId;
    }
    public String getUserWeight(){
        return userWeight;
    }

    public String getDate() {
        setCurrentDate();
        return weightEntryDate;
    }

    //Setters
    public void setUserId(long id){
        this.uId = id;
        this.userId = String.valueOf(uId);
    }

    public void setUserWeight(String uWeight) {
        this.userWeight = uWeight;
    }

    public void setCurrentDate() {
        today = new Date();
        weightEntryDate = formatter.format(today);
    }
}
