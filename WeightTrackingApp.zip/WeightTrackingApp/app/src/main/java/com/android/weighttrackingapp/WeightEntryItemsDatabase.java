package com.android.weighttrackingapp;

import android.annotation.SuppressLint;
import android.database.Cursor;
import android.content.ContentValues;
import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Build;

import java.util.ArrayList;
import java.text.SimpleDateFormat;
import java.util.List;

public class WeightEntryItemsDatabase extends SQLiteOpenHelper {

    //Variables for the class
    private static final int VERSION = 1;
    private static final String DATABASE_NAME = "WeightTrackingDB.db";
    private static WeightEntryItemsDatabase weiDB;
    private static boolean userCleared;

    private enum SubjectSortOrder {DATE, UPDATE_ASC, UPDATE_DESC};

    public static WeightEntryItemsDatabase getInstance(Context context) {
        if(weiDB == null){
            weiDB = new WeightEntryItemsDatabase(context);
        }
        return weiDB;
    }
    public WeightEntryItemsDatabase(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    //Classes of Tables DailyWeightTable, UsersTable, & GoalWeightTable
    private static final class DailyWeightTable{
        private static final String TABLE = "weight_entries";
        private static final String COL_ID = "_id";
        private static final String COL_DATE = "date";
        private static final String COL_WEIGHT = "weight";
    }
    private static final class UsersTable{
        private static final String TABLE = "users";
        private static final String COL_ID = "_id";
        private static final String COL_USERNAME= "username";
        private static final String COL_PASSWORD = "password";
    }
    private static final class GoalWeightTable{
        private static final String TABLE = "goal_weight";
        private static final String COL_ID = "_id";
        private static final String COL_GOAL = "goal";
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        //Create tables
        db.execSQL("create table " + DailyWeightTable.TABLE + " (" +
                DailyWeightTable.COL_ID + " integer primary key autoincrement, " +
                DailyWeightTable.COL_DATE + " text, " +
                DailyWeightTable.COL_WEIGHT + " text)");
        db.execSQL("create table " + UsersTable.TABLE + " (" +
                UsersTable.COL_ID + " integer primary key autoincrement, " +
                UsersTable.COL_USERNAME + " text, " +
                UsersTable.COL_PASSWORD + " text)");
        db.execSQL("create table " + GoalWeightTable.TABLE + " ( " +
                GoalWeightTable.COL_ID + " integer primary key autoincrement, " +
                GoalWeightTable.COL_GOAL + " text)");

        //
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        //Drop tables if DB upgraded
        db.execSQL("drop table if exists " + UsersTable.TABLE);
        db.execSQL("drop table if exists " + DailyWeightTable.TABLE);
        db.execSQL("drop table if exists " + GoalWeightTable.TABLE);
        onCreate(db);

    }

    @Override
    public void onOpen(SQLiteDatabase db){
        super.onOpen(db);
        if(!db.isReadOnly()){
            if(Build.VERSION.SDK_INT < Build.VERSION_CODES.JELLY_BEAN){
                db.execSQL("pragma foreign_keys = on;");
            }else{
                db.setForeignKeyConstraintsEnabled(true);
            }
        }
    }

    ///////////Method for Weight Entry//////////
    // adds dailyWeight weight entry to db
    public boolean addDailyWeightEntry (WeightEntryItem dailyWeightEntry) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(DailyWeightTable.COL_WEIGHT, dailyWeightEntry.getUserWeight());
        values.put(DailyWeightTable.COL_DATE, dailyWeightEntry.getDate().toString());
        long id = db.insert(DailyWeightTable.TABLE, null, values);
        dailyWeightEntry.setUserId(id);
        return id != -1;
    }

    //Gets a weight entry from db
    public WeightEntryItem getDailyWeightEntry() {
        SimpleDateFormat formatter = new SimpleDateFormat("MM dd, yyyy");
        WeightEntryItem dailyWeightEntry = null;
        SQLiteDatabase db = this.getReadableDatabase();
        String sql = "select * from " + DailyWeightTable.TABLE + " order by " + DailyWeightTable.COL_DATE + " DESC Limit 1";
        Cursor cursor = db.rawQuery(sql, null);
        if (cursor.moveToFirst()) {
             dailyWeightEntry = new WeightEntryItem();
            dailyWeightEntry.setUserId(cursor.getInt(0));
            dailyWeightEntry.setUserWeight(cursor.getString(1));
            dailyWeightEntry.setUserWeight(cursor.getString(2));
        }
        cursor.close();
        return dailyWeightEntry;
    }

    // updates weight entry in the db
    public void updateDailyWeight (WeightEntryItem dailyWeight) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(DailyWeightTable.COL_WEIGHT, dailyWeight.getUserWeight());
        values.put(DailyWeightTable.COL_DATE, dailyWeight.getDate().toString());
        db.update(DailyWeightTable.TABLE, values, DailyWeightTable.COL_DATE +
                " = ?", new String[] { dailyWeight.getDate().toString() });
        db.update(DailyWeightTable.TABLE, values, DailyWeightTable.COL_WEIGHT +
                " = ?", new String[] {String.valueOf(dailyWeight.getUserWeight())});
    }

    //puts users daily weight entries into a list to be displayed elsewhere
    public List<WeightEntryItem> getDailyWeightTTables() {
        @SuppressLint("SimpleDateFormat") SimpleDateFormat formatter = new SimpleDateFormat("MM dd, yyyy");
        List<WeightEntryItem> listOfDailyWeights = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();
        String sql = "select * from " + DailyWeightTable.TABLE + " order by " + DailyWeightTable.COL_DATE + " DESC";
        Cursor cursor = db.rawQuery(sql, null);
        if (cursor.moveToFirst()){
            do {
                WeightEntryItem aWeightEntry = new WeightEntryItem();
                aWeightEntry.setUserWeight(cursor.getString(2));;
                listOfDailyWeights.add(aWeightEntry);
            } while (cursor.moveToNext());
        }
        cursor.close();
        return listOfDailyWeights;
    }

    // delete a weight entry from the db
    public void deleteAWeightEntry (WeightEntryItem weightEntry) {
        SQLiteDatabase db = getWritableDatabase();
        db.delete(DailyWeightTable.TABLE, DailyWeightTable.COL_DATE +
                " = ?", new String[] { weightEntry.getDate() });
    }

    //////Methods for Goal Weight
    //Adds Goal Weight
    public boolean addGoal (GoalWeight goalWeight) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(GoalWeightTable.COL_GOAL, goalWeight.getWeight());
        long id = db.insert(GoalWeightTable.TABLE, null, values);
        goalWeight.setId(id);
        return id != -1;
    }
    //Updates Goal Weight
    public void updateGoal(GoalWeight goalWeight) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(GoalWeightTable.COL_GOAL, goalWeight.getWeight());
        db.update(GoalWeightTable.TABLE, values, GoalWeightTable.COL_ID +
                " = ?", new String[] { "1" });
    }
    //Gets users Goal Weight
    public GoalWeight getTargetWeight() {
        GoalWeight goalWeight = null;
        SQLiteDatabase db = this.getReadableDatabase();
        String sql = "select * from " + GoalWeightTable.TABLE;
        Cursor cursor = db.rawQuery(sql, null);
        if (cursor.moveToFirst()) {
            goalWeight = new GoalWeight();
            goalWeight.setId(cursor.getInt(0));
            goalWeight.setWeight(Double.parseDouble(cursor.getString(1)));
        }
        cursor.close();
        return goalWeight;
    }

    ///////////Methods for User////////
    //Adds a user to the db
    public boolean addNewUser (User user){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(UsersTable.COL_USERNAME, user.getUser());
        values.put(UsersTable.COL_PASSWORD, user.getPassword());
        long id = db.insert(UsersTable.TABLE, null, values);
        user.setId(id);
        return userCleared = true;
    }
    //Makes sure user isn't already created
    public boolean checkUser (String username, String password) {
        SQLiteDatabase db = getReadableDatabase();
        String[] variables = new String[]{username, password};
        String sql = "select * from " + UsersTable.TABLE + " where " + UsersTable.COL_USERNAME + " = ? and "
                + UsersTable.COL_PASSWORD + " = ?";
        Cursor cursor = db.rawQuery(sql, new String[]{username, password});
        int i;
        i = cursor.getCount();
        if (!cursor.moveToFirst()) {
            cursor.close();
            return userCleared = false;
        } else {
            cursor.close();
            return userCleared = true;
        }
    }
    //Gets the username
    public String getUserName(String id){
        return id;
    }
    //Updates user info if user is created
    public void updateUser(User user) {
        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(UsersTable.COL_USERNAME, user.getUser());
        values.put(UsersTable.COL_PASSWORD, user.getPassword());
        db.update(UsersTable.TABLE, values, UsersTable.COL_USERNAME +
                " = ?", new String[] { user.getUser() });
        db.update(UsersTable.TABLE, values, UsersTable.COL_PASSWORD +
                " = ?", new String[] { user.getPassword() });
    }
    //Deletes a user
    public void deleteUser (User user) {
        SQLiteDatabase db = getWritableDatabase();
        db.delete(UsersTable.TABLE, UsersTable.COL_USERNAME +
                " = ?", new String[] { user.getUser() });
    }


}
